import { pgTable, text, serial, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const commands = pgTable("commands", {
  id: serial("id").primaryKey(),
  input: text("input").notNull(),
  output: text("output").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertCommandSchema = createInsertSchema(commands).pick({
  input: true,
  output: true,
});

export type InsertCommand = z.infer<typeof insertCommandSchema>;
export type Command = typeof commands.$inferSelect;
