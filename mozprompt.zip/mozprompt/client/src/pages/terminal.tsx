import { useEffect, useRef, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { executeCommand } from "@/lib/commands";
import { themes, defaultTheme, type ThemeName } from "@/lib/themes";
import type { Command } from "@shared/schema";

export default function Terminal() {
  const [input, setInput] = useState("");
  const [history, setHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [currentTheme, setCurrentTheme] = useState<ThemeName>(defaultTheme);
  const inputRef = useRef<HTMLInputElement>(null);

  const { data: commandHistory } = useQuery<Command[]>({
    queryKey: ["/api/commands"],
  });

  const addCommand = useMutation({
    mutationFn: async (command: { input: string; output: string }) => {
      await queryClient.invalidateQueries({ queryKey: ["/api/commands"] });
      return command;
    },
  });

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const handleCommand = async () => {
    if (!input.trim()) return;

    const output = executeCommand(input);

    // Handle clear command
    if (output === 'CLEAR_TERMINAL') {
      setHistory([]);
      setInput('');
      return;
    }
    
    // Handle theme change command
    if (output.startsWith('THEME_CHANGE:')) {
      const newTheme = output.split(':')[1] as ThemeName;
      setCurrentTheme(newTheme);
      setHistory([...history, `$ ${input}`, `Theme changed to ${newTheme}`]);
    } else {
      setHistory([...history, `$ ${input}`, output]);
    }

    await addCommand.mutateAsync({ input, output });

    setInput("");
    setHistoryIndex(-1);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleCommand();
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      if (historyIndex < history.length - 1) {
        const newIndex = historyIndex + 1;
        setHistoryIndex(newIndex);
        setInput(history[history.length - 1 - newIndex]);
      }
    } else if (e.key === "ArrowDown") {
      e.preventDefault();
      if (historyIndex > 0) {
        const newIndex = historyIndex - 1;
        setHistoryIndex(newIndex);
        setInput(history[history.length - 1 - newIndex]);
      } else {
        setHistoryIndex(-1);
        setInput("");
      }
    }
  };

  const theme = themes[currentTheme];

  return (
    <div className={`min-h-screen p-4 font-mono ${theme.background} ${theme.text}`}>
      <div className="mb-4">
        <div style={{whiteSpace: 'pre', fontFamily: 'monospace'}}>
||
  Welcome to moz.prompt           
  Type 'help' for commands        
  Theme: {theme.name}.   
  have a nice day :3 ||
      </div>
      </div>

      <div className="space-y-2">
        {history.map((line, i) => (
          <pre key={i} className="text-sm whitespace-pre-wrap">{line}</pre>
        ))}
      </div>

      <div className="flex items-center mt-2">
        <span className={`mr-2 ${theme.prompt}`}>$</span>
        <input
          ref={inputRef}
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          className={`flex-1 border-none outline-none ${theme.text} ${theme.background} font-mono ${theme.selection}`}
          autoFocus
        />
      </div>
    </div>
  );
}