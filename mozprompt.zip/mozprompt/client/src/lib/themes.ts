export interface Theme {
  name: string;
  background: string;
  text: string;
  prompt: string;
  selection: string;
}

export const themes: Record<string, Theme> = {
  matrix: {
    name: 'Matrix',
    background: 'bg-black',
    text: 'text-green-500',
    prompt: 'text-green-500',
    selection: 'bg-green-900',
  },
  dracula: {
    name: 'Dracula',
    background: 'bg-gray-900',
    text: 'text-purple-300',
    prompt: 'text-pink-500',
    selection: 'bg-purple-900',
  },
  light: {
    name: 'Light',
    background: 'bg-white',
    text: 'text-gray-800',
    prompt: 'text-blue-600',
    selection: 'bg-gray-200',
  },
  retro: {
    name: 'Retro',
    background: 'bg-amber-950',
    text: 'text-amber-500',
    prompt: 'text-amber-400',
    selection: 'bg-amber-900',
  },
};

export const defaultTheme = 'retro';
export type ThemeName = keyof typeof themes;