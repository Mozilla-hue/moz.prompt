import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertCommandSchema } from "@shared/schema";

export function registerRoutes(app: Express): Server {
  app.get("/api/commands", async (_req, res) => {
    const history = await storage.getCommandHistory();
    res.json(history);
  });

  app.post("/api/commands", async (req, res) => {
    const parsed = insertCommandSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "Invalid command data" });
      return;
    }

    const command = await storage.addCommand(parsed.data);
    res.json(command);
  });

  const httpServer = createServer(app);
  return httpServer;
}
