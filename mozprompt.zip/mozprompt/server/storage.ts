import { commands, type Command, type InsertCommand } from "@shared/schema";

export interface IStorage {
  getCommandHistory(): Promise<Command[]>;
  addCommand(command: InsertCommand): Promise<Command>;
}

export class MemStorage implements IStorage {
  private commands: Command[];
  private currentId: number;

  constructor() {
    this.commands = [];
    this.currentId = 1;
  }

  async getCommandHistory(): Promise<Command[]> {
    return this.commands;
  }

  async addCommand(insertCommand: InsertCommand): Promise<Command> {
    const command: Command = {
      id: this.currentId++,
      ...insertCommand,
      timestamp: new Date(),
    };
    this.commands.push(command);
    return command;
  }
}

export const storage = new MemStorage();
